// import React from 'react';
// import { Route, Redirect } from 'react-router-dom';
// import { Header } from './Header';

// export const PrivateRoute = ({ component: Component, ...rest }) => (
//     <Route {...rest} render={props => (
//         localStorage.getItem('user')
//             ? <React.Fragment>
//                 <Header/>
//                 <Component {...props} />
//                 </React.Fragment>
//             : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
//     )} />
// )