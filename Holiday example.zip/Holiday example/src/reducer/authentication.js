import { holidayConstants } from '../actions/actionTypes';

const initialState = [];

export function authentication(state = initialState, action) {
  switch (action.type) {
    case 'temp':
    default:
      return state
  }
}