import { combineReducers } from 'redux';
import { holidays } from './holidays';

export const rootReducer = combineReducers({ holidays })
