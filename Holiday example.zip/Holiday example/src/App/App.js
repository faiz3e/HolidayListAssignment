import React from 'react';
import { connect } from 'react-redux';
import { Login } from '../Pages/Login'
import { SignUp } from "../Pages/SignUp";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
} from "react-router-dom";
import './App.css';
import { HomePage } from '../Pages/HomePage/Homepage';
import { PrivateRoute } from '../components/PrivateRoute';


class App extends React.Component {
  render() {
    return (
      <div className="container-fluid app-bg">
        <div className="col-sm-12 col-sm-offset-2">
          <Router>
            <Switch>
              {/* <PrivateRoute exact path="/" component={HomePage} /> */}
              <Route path="/" component={HomePage} />
              <Route path="/register" component={SignUp} />
              <Redirect from="*" to="/" />
            </Switch>
          </Router>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return state;
}

const connectedApp = connect(mapStateToProps)(App);
export { connectedApp as App };