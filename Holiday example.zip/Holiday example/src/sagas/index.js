import { all, fork } from 'redux-saga/effects';
import { holidays } from "./holidays";

export function* rootSaga() {
    yield all([fork(holidays)]);
}