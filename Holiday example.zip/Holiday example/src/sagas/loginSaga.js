// import { takeLatest, call, put } from "redux-saga/effects";
// import { holidayConstants } from '../actions/actionTypes';
// import { history } from '../helpers/history';

// export function* loginSaga() {
// 	yield takeLatest(holidayConstants.HOLIDAY_GET, workerSaga);
// }

// function* workerSaga(action) {
// 	try {
// 		yield put({ type: holidayConstants.HOLIDAY_REQUEST });
// 	}
// 	catch (error) {
// 		console.log("err",error)
// 	}
// }


