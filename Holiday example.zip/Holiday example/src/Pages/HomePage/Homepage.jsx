import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { getHoliday } from '../../actions/userActions';

const HomePage = (props) => {

  const loginHandler = () => {
    props.getHoliday({ email: "", password: "" })
  }
  
  return (
    <div className="App">
      <button type="btn" className="btn btn-primary btn-lg" onClick={loginHandler}>get all holiday</button>
      {props.data && props.data.map((item, i) => {
        return (
          <div key={i}>
            <p>{item.summary}</p>
          </div>)
      })}
    </div>
  );
}

function mapState(state) {
  return state.holidays;
}

const mapDispatchToProps = (dispatch) => {
  return {
    getHoliday: (data) => dispatch(getHoliday(data)),
  }
}
const connectedHomePage = connect(mapState, mapDispatchToProps)(HomePage);
export { connectedHomePage as HomePage };