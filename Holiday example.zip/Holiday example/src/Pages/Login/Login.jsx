import React, { useEffect } from 'react';
import { connect } from 'react-redux';

const LoginPage = (props) => {
  return (
    <div className="App">
    </div>
  );
}

const connectedLoginPage = connect(null)(LoginPage);
export { connectedLoginPage as Login };